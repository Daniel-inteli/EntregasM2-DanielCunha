var g = 10
var VelocidadeInicial
var AlturaMaxima
var TempoSubida
function Am() {
    VelocidadeInicial = document.getElementById("VelocidadeInicial").value;
    AlturaMaxima = ((VelocidadeInicial * VelocidadeInicial) / 2 * g)
    TempoSubida = VelocidadeInicial / g
    alert("Altura maxima = " + AlturaMaxima + " metro(s)");
    alert("Tempo de subida = " + TempoSubida + " segundo(s)");
}